import { BbrConfigModule } from '@bbr/api-core/modules/config/configModule';
import { BbrCoreModule } from '@bbr/api-core/modules/core.module';
import { MongooseModule } from '@nestjs/mongoose';
import { ServiceConfig } from './config';
import { Module } from '@nestjs/common/decorators';
import { PostModule } from './posts/post.module';
import { UserModule } from './users/user.module';
  import { ConfigModule } from '@nestjs/config';
  import { Logger } from '@nestjs/common';
@Module({
  imports: [
    BbrConfigModule.forRoot({
      useClass: ServiceConfig,
    }),
    MongooseModule.forRoot('mongodb://localhost:27017/BbrBackend'),
    UserModule,
  ],
  // controllers: [],
  // providers: [],
})
export class AppModule {}
