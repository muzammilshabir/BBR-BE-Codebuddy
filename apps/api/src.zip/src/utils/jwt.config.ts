import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

const path = require('path');
const envPath = path.resolve(__dirname, '..', '..', '.env');
require('dotenv').config({path: envPath});



import { JwtModuleOptions } from '@nestjs/jwt';
console.log("test",envPath);
export const jwtConstants = {
  // secret: process.env.JWT_SECRET_KEY, // Replace with a strong secret key  
  secret: "tsdkkcmcakdasdasdcnjcdhbfhd",
};

export const jwtConfig: JwtModuleOptions = {
  secret: jwtConstants.secret,
  signOptions: { expiresIn: '1h' }, // Token expiry time
};
